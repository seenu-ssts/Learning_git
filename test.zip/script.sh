#! /bin/bash

# cd /home/$USER/ios/Ios_Ubuntu_16/

# unzip libxml2-master.zip
# cd libxml2-master
# ./autogen.sh
# make
# sudo make install
# cd ..

# unzip libplist-master.zip
# cd libplist-master/
# ./autogen.sh
# make
# sudo make install
# cd ..

# unzip libusbmuxd-master.zip
# cd libusbmuxd-master/
# ./autogen.sh
# make
# sudo make install
# cd ..

# unzip libusb-master.zip
# cd libusb-master/
# ./autogen.sh
# make
# sudo make install
# cd ..

# unzip libusbmuxd-master.zip
# cd libusbmuxd-master/
# ./autogen.sh
# make
# sudo make install
# cd ..

# unzip libimobiledevice-master.zip
# cd libimobiledevice-master/
# ./autogen.sh
# make
# sudo make install
# cd ..

# tar xvf usbmuxd-1.1.0.tar.bz2
# cd usbmuxd-1.1.0/
# ./configure
# make
# sudo make install
# cd..

# unzip ideviceinstaller-master.zip
# cd ideviceinstaller-master/

# #sudo nano src/ideviceinstaller.c

# sed -i '/while(zfsize < zs.size) {/c\while (zfsize < (zipunit64_t)zs.size){' src/ideviceinstaller.c

# ./autogen.sh
# make
# sudo make install
# cd ..

# unzip libvncserver-master.zip
# cd libvncserver-master/
# ./autogen.sh
# make
# sudo make install
# cd ..
# cd ~

cd /home/srinivasan-pc/pCloudy-Executables-Code/Anshuman-Effect/rBox/build/javascript

set -x verbose $echo on
git fetch origin
counter=0;
while read -a i;
do
	fileOp[$counter]=${i[0]};
	fileName[$counter]=${i[1]};

	blankString='';
	strippedOffFileName[$counter]=${fileName[$counter]/javascript\//$blankString};
	#the above line will replace 'WebSite' from the fileName by a blankString

	echo ${strippedOffFileName[$counter]};

	counter=$((counter+1));
#done < <(git diff master origin --name-status ./www)
done < <(git diff  origin/script-for-deployment-process:Anshuman-Effect/rBox/build/javascript ~/pCloudy-Executables-Code/Anshuman-Effect/rBox/build/javascript)

git pull

#exit

#Now go inside the  Public_Cloud folder, so that the strippedOffFileName start with the www folder
#cd Public_Cloud

for (( i=0; i<$counter; i++ ))
do
	echo ${fileOp[$i]};
	if [ ${fileOp[$i]} == 'A' ]; then
		sudo cp --parents ${strippedOffFileName[$i]} /var/
	else if [ ${fileOp[$i]} == 'M' ]; then
			sudo cp --parents ${strippedOffFileName[$i]} /var/
			else if [ ${fileOp[$i]} == 'D' ]; then
				#sudo rm /var/${fileName[$i]}
				sudo rm /var/${strippedOffFileName[$i]}
			fi
	fi
	fi
done

#cp -f /home/padmin/server-local-copy/pcloudy/rBox/sync/device-sync.js  /home/padmin/build/device-sync.js
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/sync/debug-proxy.js  /home/padmin/build/debug-proxy.js
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/sync/start-server.sh /home/padmin/build/start-server.sh
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/sync/stop-server.sh /home/padmin/build/stop-server.sh
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/sync/server.js /home/padmin/build/server.js
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/sync/debug-server.js /home/padmin/build/debug-server.js

#cp -f /home/padmin/server-local-copy/pcloudy/rBox/generateOfflineReport.pl /home/padmin/build/generateOfflineReport.pl
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/generatePrintReport.pl /home/padmin/build/generatePrintReport.pl
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/generateOfflineWebReport.pl /home/padmin/build/generateOfflineWebReport.pl
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/generatePrintWebReport.pl /home/padmin/build/generatePrintWebReport.pl
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/generateOfflineCrawlReport.pl /home/padmin/build/generateOfflineCrawlReport.pl
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/generatePrintCrawlReport.pl /home/padmin/build/generatePrintCrawlReport.pl
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/generateCalabashOfflineReport.pl /home/padmin/build/generateCalabashOfflineReport.pl
#cp -f /home/padmin/server-local-copy/pcloudy/rBox/generateCalabashPrintReport.pl /home/padmin/build/generateCalabashPrintReport.pl


cd /home/srinivasan-pc/pCloudy-Executables-Code/Anshuman-Effect/rBox/build/
./stop-server.sh

cd /home/srinivasan-pc/pCloudy-Executables-Code/Anshuman-Effect/rBox/build/
./start-server.sh